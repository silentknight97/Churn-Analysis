library(dplyr) # for data cleaning
library(cluster) # for gower similarity and pam
library(Rtsne) # for t-SNE plot
library(ggplot2) # for visualization
missclassified.clusterData=missclassified2[,c(11,18,21,22,8)]
#df <- merge(trainData, clusterData, by.x = "customerID", by.y = "tweet")
testData.cusID=testData[,1]


# Remove college name before clustering

gower_dist <- daisy(missclassified.clusterData,
                    metric = "gower",
                    type = list(logratio = 3))

# Check attributes to ensure the correct methods are being used
# (I = interval, N = nominal)
# Note that despite logratio being called, 
# the type remains coded as "I"

summary(gower_dist)

gower_mat <- as.matrix(gower_dist)

# Output most similar pair

missclassified.clusterData[
  which(gower_mat == min(gower_mat[gower_mat != min(gower_mat)]),
        arr.ind = TRUE)[1, ], ]
##                            name accept_rate Outstate Enroll
## 682 University of St. Thomas MN   0.8784638    11712    828
## 284     John Carroll University   0.8711276    11700    820
##     Grad.Rate Private   isElite
## 682        89     Yes Not Elite
## 284        89     Yes Not Elite
# Output most dissimilar pair

missclassified.clusterData[
  which(gower_mat == max(gower_mat[gower_mat != max(gower_mat)]),
        arr.ind = TRUE)[1, ], ]
##                                        name accept_rate
## 673 University of Sci. and Arts of Oklahoma   0.9824561
## 251                      Harvard University   0.1561486
##     Outstate Enroll Grad.Rate Private   isElite
## 673     3687    208        43      No Not Elite
## 251    18485   1606       100     Yes     Elite


# Calculate silhouette width for many k using PAM

sil_width <- c(NA)

for(i in 2:10){
  
  pam_fit <- pam(gower_dist,
                 diss = TRUE,
                 k = i)
  
  sil_width[i] <- pam_fit$silinfo$avg.width
  
}

# Plot sihouette width (higher is better)

plot(1:10, sil_width,
     xlab = "Number of clusters",
     ylab = "Silhouette Width")
lines(1:10, sil_width)

pam_fit <- pam(gower_dist, diss = TRUE, k = 7)

#clusterData[540,]
#InternetService       Contract MonthlyCharges TotalCharges
#751             DSL Month-to-month           56.7      1652.95
#clusterData[1898,]
#InternetService       Contract MonthlyCharges TotalCharges
#2688     Fiber optic Month-to-month             91      2626.15
#clusterData[968,]
#InternetService Contract MonthlyCharges TotalCharges
#1371              No Two year          20.25        538.2


#include Customer ID in clus data
missclassified.clusterData$id=missclassified2$customerID
tsne_obj <- Rtsne(gower_dist, is_distance = TRUE,perplexity = 70)

tsne_data <- tsne_obj$Y %>%
  data.frame() %>%
  setNames(c("X", "Y")) %>%
  mutate(cluster = factor(pam_fit$clustering),
         name = missclassified.clusterData$id)
clus.plot=as.data.frame(tsne_data)
ggplot(aes(x = X, y = Y), data = tsne_data) +
  geom_point(aes(color = cluster))

test.cluster1 <- subset(clus.plot, cluster==1)
test.cluster2 <- subset(clus.plot, cluster==2)
test.cluster3 <- subset(clus.plot, cluster==3)
test.cluster4 <- subset(clus.plot, cluster==4)
test.cluster5 <- subset(clus.plot, cluster==5)
test.cluster6 <- subset(clus.plot, cluster==6)
test.cluster7 <- subset(clus.plot, cluster==7)
test.level1_cluster <- merge(test.cluster1, missclassified2, by.x = "name", by.y = "customerID")
test.level2_cluster <- merge(test.cluster2, missclassified2, by.x = "name", by.y = "customerID")
test.level3_cluster <- merge(test.cluster3, missclassified2, by.x = "name", by.y = "customerID")
test.level4_cluster <- merge(test.cluster4, missclassified2, by.x = "name", by.y = "customerID")
test.level5_cluster <- merge(test.cluster5, missclassified2, by.x = "name", by.y = "customerID")
test.level6_cluster <- merge(test.cluster6, missclassified2, by.x = "name", by.y = "customerID")
test.level7_cluster <- merge(test.cluster7, missclassified2, by.x = "name", by.y = "customerID")
write.csv(test.level1_cluster,"missclassified.cluster1.csv")
write.csv(test.level2_cluster,"missclassified.test.cluster2.csv")
write.csv(test.level3_cluster,"missclassified.test.cluster3.csv")
write.csv(test.level4_cluster,"missclassified.test.cluster4.csv")
write.csv(test.level5_cluster,"missclassified.test.cluster5.csv")
write.csv(test.level6_cluster,"missclassified.test.cluster6.csv")
write.csv(test.level7_cluster,"missclassified.test.cluster7.csv")
summary(test.level4_cluster)
