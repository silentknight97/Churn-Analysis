library(randomForest)
library(mlbench)
library(caret)

control <- trainControl(method="repeatedcv", number=10, repeats=3)
seed <- 7
metric <- "Accuracy"
set.seed(seed)
mtry <- sqrt(ncol(trainData)-1)
tunegrid <- expand.grid(.mtry=mtry)
rf_default <- train(Churn~.-(Partner+gender), data=trainData, method="rf", metric=metric, tuneGrid=tunegrid, trControl=control)
print(rf_default)


# Random Search
control <- trainControl(method="repeatedcv", number=10, repeats=3, search="random")
set.seed(seed)
mtry <- sqrt(ncol(trainData)-1)
rf_random <- train(Churn~., data=trainData, method="rf", metric=metric, tuneLength=15, trControl=control)
print(rf_random)
plot(rf_random)


test.predictions= predict(rf_default,testData)
fitted.results <- ifelse(test.predictions == "Yes",1,0)
testData$Churn <- as.character(testData$Churn)
testData$Churn[testData$Churn=="No"] <- "0"
testData$Churn[testData$Churn=="Yes"] <- "1"
misClasificationError <- mean(fitted.results!=testData$Churn)
print(misClasificationError)

# calculating the accuracy rate
accuracyRate <- 1-misClasificationError
print(accuracyRate)

