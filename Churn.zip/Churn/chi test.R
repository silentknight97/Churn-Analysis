data.frame(RF = sort(importance(fit)[, "MeanDecreaseGini"], decreasing = TRUE)) %>% add_rownames() %>% rename(Predictor = rowname)
importance=as.data.frame(importance(fit))
tb1=table(trainData$PhoneService, trainData$Churn)
l=14
p.val <- vector(mode = "numeric", length = l)
for (i in 4:18) {
  chi=chisq.test(trainData[,i],trainData$Churn)
  p.val[i-3]<-chi$p.value
}
p.val
chi=chisq.test(trainData$PhoneService,trainData$Churn)
chi$expected
library(MASS) 
?chisq.test
class(tb1)
dimnames(tb1)

dimnames(tb1) <- list(gender = c("F", "M"),
                    Churn = c("Yes","No"))
M
(Xsq <- chisq.test(M))
tb1[2]
